<?php

return [
    'adminEmail' => 'sergioreyes_90290@hotmail.com',
];
