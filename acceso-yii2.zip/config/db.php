<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=acceso_yii2',
    'username' => 'root',
    'password' => 'checo90290',
    'charset' => 'utf8',
];
