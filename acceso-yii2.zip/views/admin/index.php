<?php

/* @var $this yii\web\View */

$this->title = 'Acceso grafico';
use yii\helpers\Html;
use yii\widgets\ActiveForm;
?>


<div class="container">
	<div class="text-center">
		<h1>Bienvenido al Administrador</h1>
	</div>
</div>