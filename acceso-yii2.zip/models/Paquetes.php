<?php
namespace app\models;

use yii\db\ActiveRecord;

class Paquetes extends ActiveRecord
{
    
}

?>