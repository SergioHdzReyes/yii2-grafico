<?php
namespace app\models;

use yii\db\ActiveRecord;

class Footer extends ActiveRecord
{
    
}

?>