<?php
namespace app\models;

use yii\db\ActiveRecord;

class Nosotros extends ActiveRecord
{
    
}

?>